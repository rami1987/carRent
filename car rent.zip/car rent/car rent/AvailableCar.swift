//
//  AvailableCar.swift
//  car rent
//
//  Created by Macbook  on 30/09/2025.
//

import SwiftUI

struct AvailableCar: View {
    @State private var availableCars: [Carrr] = []
       
       var body: some View {
           List {
               if availableCars.isEmpty {
                   Text("No available cars")
                       .foregroundColor(.secondary)
                       .italic()
               } else {
                   ForEach(AdminCoreDataManager.getAvailableCars()) { car in
                       Celltabel(car: car)
                   }
               }
           }
           .navigationTitle("Available Cars")
           .onAppear {
               loadAvailableCars()
           }
       }
       
       private func loadAvailableCars() {
           let allCars = AdminCoreDataManager.fetchAllCars()
           availableCars = allCars.filter { $0.isavailable }
       }
   }

struct AvailableCar_Previews: PreviewProvider {
    static var previews: some View {
        AvailableCar()
    }
}

//
//  carListView.swift
//  car rent
//
//  Created by Macbook  on 25/08/2025.
//

import SwiftUI

struct carListView: View {
    var body: some View {
        
         NavigationView() {
            List{
                ForEach(AdminCoreDataManager.fetchAllCars()) { item in
                    NavigationLink(destination: CarDetailView(car: item)){
                        Celltabel(car: item)
                    }
              
                }
               
            }//List
            
        }//navigationView
    }
    
}

struct carListView_Previews: PreviewProvider {
    static var previews: some View {
        carListView()
    }
}

//
//  Header.swift
//  car rent
//
//  Created by Macbook  on 06/09/2025.
//

import SwiftUI

struct Login: View {
    @EnvironmentObject var userManager: CurrentCustomer
    @State var email:String = ""
    @State var password:String = ""
    let pleacholdermail:String = ""
    let pleaceholderpass:String = ""
    @State private var errorMessage = ""
    @State private var showError = false
    @State private var isLoggedIn = false
    @State private var isLoggingIn = false
    @State private var isShowingViewPlus = false
    @State private var goToRegister = true
    @State var isNavigatingToManagerDashboard = false
    @State var isNavigationtoCustomer = false
    
    
    
    var body: some View {
        NavigationView {
            VStack{
                VStack {
                    Image("rami")
                        .resizable()
                        .scaledToFit()
                        .clipShape(Circle())
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                
                VStack(alignment: .center ,spacing: 12 ) {
                    
                    Text("MAIL ADDRESS")
                        .foregroundColor(.gray)
                        .font(.footnote)
                        .fontWeight(.heavy)
                    
                    TextField(pleacholdermail,text: $email)
                        .autocapitalization(.none)
                    Divider()
                    
                    Text("PASSWORD")
                        .foregroundColor(.gray)
                        .font(.footnote)
                        .fontWeight(.heavy)
                    
                    TextField(pleaceholderpass,text: $password)
                        .autocapitalization(.none)
                    Divider()
                    
                        .padding((.horizontal))
                    
                    HStack{
                    
                    Button {
                        //calling handle login method which return completion handler closuer
                        handleLogin { success in
                            
                            if success {
                                guard  let user = userManager.currentUser else{
                                    print("cant load the user")
                                    return
                                }
                                if user.isManager{
                                    isNavigatingToManagerDashboard.toggle()
                                }else{
                                    isNavigationtoCustomer.toggle()
                                }
                                }
                            //empty the values of inputs
                            email  = ""
                            password = ""
                            
                        }
                    } label: {
                        Text("login")
                            .frame(maxWidth: .infinity)

                            .padding(20)
                            .background(Color.gray)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            
                    }
                    
                    
                        NavigationLink(destination: Register(email: "", password: "", name: "", userName: "")){
                                    Text("register")
                                        .frame(maxWidth: .infinity)
                                        .padding(20)
                                        .foregroundColor(.white)
                                        .background(.gray)
                                        .cornerRadius(10, antialiased: true)
                        }
                        NavigationLink(destination: ManagerDashboard(),isActive: $isNavigatingToManagerDashboard,label: { EmptyView() })
                        NavigationLink(destination: ContentView(),isActive: $isNavigationtoCustomer,label: { EmptyView() })

                                }//hstack
            }//vstack
            .padding(.horizontal,15 )
            .frame(maxHeight: .infinity)
            .navigationTitle("Login")
                
                NavigationLink(
                    
                    destination: carListView(),
                    isActive: $isShowingViewPlus,
                    label: { EmptyView() }
                )
                
                
            Spacer()
            
                .frame(maxHeight: .infinity)
        }//outer vstack
        
        .padding(.horizontal,40 )
        .frame(maxHeight: .infinity)
        
    }
}
    
    private func handleLogin(completion: @escaping (Bool) -> Void ){
        //
            isLoggingIn = true //the main goal is to present the progress view while thead
            errorMessage = ""
            // Simulate network delay (remove in production)
         //   DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [self] in
                //the result here is a tuple 3 variables
        let result = CoreDataManager.shared.loginUser(email: self.email, password: self.password ,userManager:userManager)
                
                isLoggingIn = false
                
                if result.success {
                    // Login successful - save user session if needed
                    saveUserSession(result.customer)
                    isLoggedIn = true
                    
                    print(" im in handle login method \(isLoggedIn)")
                } else {
                    errorMessage = result.error ?? "Login failed"
                    showError = true
                    print("im cant log in")
                    
                }
                
           // }
        completion( isLoggedIn)
        }

    private func saveUserSession(_ customer: Customerr?) {
           // Save user session to UserDefaults or Keychain
           if let customer = customer {
               UserDefaults.standard.set(customer.email, forKey: "currentUserEmail")
               UserDefaults.standard.set(true, forKey: "isLoggedIn")
               print("User session saved for: \(customer.email ?? "Unknown")")
           }
       }
    
    }


struct Header_Previews: PreviewProvider {
    static var previews: some View {
        Login(email: "", password: "")

    }
}
/**
 Joodayashi@gmail.com
 123456
 */

//
//  Register.swift
//  car rent
//
//  Created by Macbook  on 13/09/2025.
//

import SwiftUI
import CoreData
import Combine
struct Register: View {
    @EnvironmentObject var userManager: CurrentCustomer
    @State var email:String
    @State var password:String
    @State var name:String
    @State var userName:String
    @State private var showPinField = false
    @State private var pin = ""
      var adminpin = "300973880"
    @State var isregisterd = false //check weather the calling is saved or not 
    @State var  isNavigatingToLogin = false// for main view
    @State  var isNavigatingToManagerDashboard = false
    @State var isNavigationtoCustomer = false
    var body: some View {
        NavigationView {
            ScrollView{
                VStack{
                    VStack{
                        Image("rami")
                            .resizable()
                            .scaledToFit()
                            .clipShape(Circle())
                            .frame(width: UIScreen.main.bounds.width*0.7,height: UIScreen.main.bounds.width*0.7)
                    }
                    VStack(alignment: .center ,spacing: 13) {
                        Text("full name")
                            .foregroundColor(.gray)
                            .font(.footnote)
                            .fontWeight(.heavy)
                        
                        TextField("enter your name",text: $name)
                        
                        Text("username")
                            .foregroundColor(.gray)
                            .font(.footnote)
                            .fontWeight(.heavy)
                            .autocapitalization(.none)
                        TextField("enter your username",text: $userName)
                        
                        Text("email")
                            .foregroundColor(.gray)
                            .font(.footnote)
                            .fontWeight(.heavy)
                        
                        TextField("ënter your email",text: $email  )
                            .autocapitalization(.none)
                        Text("PASSWORD")
                            .foregroundColor(.gray)
                            .font(.footnote)
                            .fontWeight(.heavy)
                        
                        SecureField("enter your password",text: $password)
                        
                        HStack(){
                            
                            Button(action: {
                                withAnimation {
                                    showPinField.toggle()
                                }
                            }) {
                                Text( "manager")
                                    
                            }
                            .frame(maxWidth: .infinity)
                                .font(.subheadline)
                                .fontWeight(.heavy)
                                .padding(8)
                                .background(Color.white.opacity(0.8))
                                .foregroundColor(.black)
                                .cornerRadius(8)
                            Spacer()
                                .frame(maxWidth: .infinity)
                            if showPinField {
                                TextField("PIN", text: $pin)
                                    .textFieldStyle(.roundedBorder)
                                    .keyboardType(.numberPad)
                                    .frame(maxWidth: 150)
                                    .transition(.opacity.combined(with: .move(edge: .top)))
                                    .frame(minWidth: 30)
                            }
                            Spacer()
                        }.padding(.horizontal,20)

                            
                            //you need to end the navigation view then write the navigation link
                        HStack(){
                            Button {
                                isregisterd = saveCustomer()
                                print("goto main customer")
                                if isregisterd{
                                    guard  let user = userManager.currentUser else{
                                        print("cant load the user")
                                        return
                                    }
                                    if user.isManager{
                                        isNavigatingToManagerDashboard.toggle()
                                    }else{
                                        isNavigationtoCustomer.toggle()
                                    }
                                }
                            } label: {
                                Text("submit")
                                    
                            }.frame(maxWidth: .infinity)
                                .font(.subheadline)
                                .padding(8)
                                .background(Color.blue.opacity(0.8))
                                .foregroundColor(.white)
                                .cornerRadius(8)
                            //submit button
                            Button(action: {
                                isNavigatingToLogin.toggle()
                                print("goto login page")}, label:
                                    {Text("login")
                                    
                                
                            })
                            
                            .frame(maxWidth: .infinity)
                            .font(.subheadline)
                            .padding(8)
                            .background(Color.blue.opacity(0.8))
                            .foregroundColor(.white)
                            .cornerRadius(8)
                        }//2HStack
                        .padding(.horizontal,20)
                            
                        
                        
                    }//vstack
    NavigationLink(destination: Login(),isActive: $isNavigatingToLogin,label: { EmptyView() })
    NavigationLink(destination: ManagerDashboard(),isActive: $isNavigatingToManagerDashboard,label: { EmptyView() })
    NavigationLink(destination: ContentView(),isActive: $isNavigationtoCustomer,label: { EmptyView() })

                        

                }//outer vstack
                
                .frame(minWidth: 100 ,maxWidth: UIScreen.main.bounds.width, minHeight: 500 ,maxHeight: UIScreen.main.bounds.height)
                
                .padding(.horizontal,10)
                Spacer()
            }//scrollview end
            .onReceive(Just(pin)){newvalue in
                if newvalue == adminpin{
                }
            }
       
        }//navigation view
            
    }
    
    private func saveCustomer()->Bool {
        //check if the customer is truelly manager or not
        var ismanager = false
        if pin==adminpin{
            ismanager = true
        }
        //call the saveCustomer funtion
        let regesterStats:Bool = CoreDataManager.shared.saveCustomer(
              name: name,
              userName: userName,
              mail: email,
              password: password,pin: pin,ismanager:ismanager,
              userManager:self.userManager
          )
          
          // Clear fields after saving
          name = ""
          userName = ""
          email = ""
          password = ""
        return regesterStats
      }
    
   
}



struct Register_Previews: PreviewProvider {
    static var previews: some View {
        Register(email: "", password: "", name: "", userName:"")
    }
}

/*
 RECORD IN CORE DATA CUSTOMER
 Athar Khalil
 Athar_khalil
 Athar1993@GMAIL.COM
 0559289988
 */

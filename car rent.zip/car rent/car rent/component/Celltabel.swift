//
//  Celltabel.swift
//  car rent
//
//  Created by Macbook  on 25/08/2025.
//

import SwiftUI

struct Celltabel: View {
    var car:Carrr
    func getGradient ()->[Color]{
        guard let colors = car.gradientColors, colors.count >= 2 else {
               return [Color.gray, Color.gray] // أو أي ألوان افتراضية
           }

           return [Color(colors[0]), Color(colors[1])]
    }
    
    @State private var showDatePicker = false
        @State private var startDate = Date()
        @State private var endDate = Date()
    var body: some View {
        HStack{
            Image(uiImage: (car.image ?? UIImage(named: "bmw"))!  )
                .resizable()
                .scaledToFit()
                .frame(width: 80 ,height: 80,alignment: .center)
                .background(LinearGradient(gradient: Gradient(colors: self.getGradient()), startPoint: .topLeading, endPoint: .bottomTrailing  ))
            VStack(alignment: .leading, spacing: 3){
                Text(car.title)
                    .font(.title2)
                    .fontWeight(.heavy)
                Text(car.headline)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .lineLimit(3)
                
            }
            Button {
                withAnimation {
                            showDatePicker.toggle()
                            }
            } label: {
                Text("rent")
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)
                            

             Spacer()
             
           
                       }
                       
            
        }
    
}

struct Celltabel_Previews: PreviewProvider {
    static var previews: some View {
        let context = CoreDataManager.preview.persistentContainer.viewContext // للبروفايو
             let car = Carrr(context: context)
             car.title = "Toyota"
        car.headline = "Mercedes-Benz, commonly referred to as just Mercedes, is a German luxury automotive marque. Both Mercedes-Benz and Mercedes-Benz AG are headquartered in Stuttgart, Baden-Württemberg, Germany."
        car.image = (UIImage(named: "bmw"))
        car.carDescription = """
      Mercedes-Benz traces its origins to Karl Benz's creation of the first internal combustion engine in a car, seen in the Benz Patent Motorwagen – financed by Bertha Benz's dowry[10] and patented in January 1886[11] – and Gottlieb Daimler and their engineer Wilhelm Maybach's conversion of a stagecoach, with the addition of a petrol engine, introduced later that year. The Mercedes automobile was first marketed in 1901 by Daimler-Motoren-Gesellschaft (DMG).

      Emil Jellinek, a European automobile entrepreneur who worked with Daimler Motoren Gesellschaft (DMG), registered the trademark in 1902, naming the 1901 Mercedes 35 hp after his daughter Mercedes Jellinek. Jellinek was a businessman and marketing strategist who promoted "horseless" Daimler automobiles among the highest circles of society in his adopted home. At the time, it was a meeting place for the "Haute Volée" of France and Europe, especially in winter. His customers included the Rothschild family and other well-known people. But Jellinek's plans went further, and in as early as 1901, he was selling Mercedes cars in the "New World" as well, including United States billionaires Rockefeller, Astor, Morgan, and Taylor. At the Nice race he attended in 1899, Jellinek drove under the pseudonym "Monsieur Mercédès" as a way of concealing his less fancy real name. Many consider that race the time of birth for Mercedes-Benz as a brand. Later, in 1901, the name "Mercedes" was re-registered by DMG worldwide as a protected trademark.[12] The first Mercedes-Benz branded vehicles were produced in 1926, following the merger of Karl Benz's and Gottlieb Daimler's companies into the Daimler-Benz company on 28 June of the same year.
      """
             return Celltabel(car: car)
                 .environment(\.managedObjectContext, context)
    }
}

//
//  CardView.swift
//  car rent
//
//  Created by Macbook  on 22/08/2025.
//

import SwiftUI

struct CardView: View {
    
    var car:Carr
    var body: some View {
        
        VStack{
            Image(car.image)
                .resizable()
                .scaledToFit()
                .padding()
            Text(car.title)
                .font(.largeTitle)
                .fontWeight(.heavy)
                .foregroundColor(.blue)
            Text(car.headline)
                .font(.headline)
                .multilineTextAlignment(.center)
                .lineLimit(2)
                .foregroundColor(.blue)
            Button {
                print("ziad my lovely son ")
            } label: {
                Image(systemName:"arrow.right.circle")
                Text("start")
            }
            .font(.largeTitle)
            .padding(.horizontal,15)
            .padding(.vertical,10)
            .background(Capsule().strokeBorder(Color.blue,lineWidth: 15))

            
        }//vstack
        .shadow(color: Color(red:0, green:0 ,blue:0 ,opacity: 0.5), radius:2 ,x:2, y:2 )
        .frame( minWidth: 0, maxWidth: .infinity,minHeight: 0, maxHeight: .infinity,alignment: .center )
        .background(LinearGradient(gradient: Gradient(colors: car.gradientColors), startPoint: .topLeading, endPoint: .bottomTrailing))
    }
}

struct CardView_Previews: PreviewProvider {
    static var previews: some View {
        CardView(car: carsData[4])
    }
}

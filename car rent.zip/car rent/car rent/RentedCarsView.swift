//
//  RentedCarsView.swift
//  car rent
//
//  Created by Macbook  on 01/10/2025.
//

import SwiftUI

struct RentedCarsView: View {
    @State private var rentedCars: [Carrr] = []
    @State private var activeRentals: [CarRental] = []
    
    var body: some View {
        Text("heloo")
        List {
            if rentedCars.isEmpty {
                Text("No rented cars")
                    .foregroundColor(.secondary)
                    .italic()
            } else {
                ForEach($rentedCars, id: \.id) { car in
                    
                        ForEach(AdminCoreDataManager.fetchAllCars()) { item in
                            NavigationLink(destination: CarDetailView(car: item)){
                                Celltabel(car: item)
                            }
                      
                        }
                       
                    
                }
            }
        }
        .navigationTitle("Rented Cars")
        .onAppear {
            loadRentedCars()
        }
    }

         private func loadRentedCars() {
         let allCars = AdminCoreDataManager.fetchAllCars()
         rentedCars = allCars.filter { !$0.isavailable }
         activeRentals = RentalDataManager.fetchActiveRentals()
         }
         
         private func getRentalForCar(_ car: Carrr) -> CarRental? {
         return activeRentals.first { $0.car.id == car.id }
         }
    
}
struct RentedCarsView_Previews: PreviewProvider {
    static var previews: some View {
        
        RentedCarsView()
    }
}

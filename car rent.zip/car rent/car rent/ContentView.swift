//
//  ContentView.swift
//  car rent
//
//  Created by Macbook  on 21/08/2025.
//
// the main Customer Dashbourd page
import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            ZStack {
                // خلفية خفيفة
                LinearGradient(
                    colors: [.blue.opacity(0.2), .white],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()

                VStack(spacing: 30) {
                    Text("🚗 customer service")
                        .font(.largeTitle)
                        .bold()
                        .padding(.top, 20)

                    VStack(spacing: 20) {
                        HomeButton(
                            title:"rent car",
                            icon: "car.fill",
                            color: .blue,
                            destination: AnyView(carListView())
                        )

                        HomeButton(
                            title: "return car",
                            icon: "list.bullet.rectangle.portrait",
                            color: .green,
                            destination: AnyView(carListView())
                        )

                        HomeButton(
                            title: "الزبائن",
                            icon: "person.3.fill",
                            color: .orange,
                            destination: AnyView(AdminController())
                        )
                    }

                   // Spacer()
                }
                .padding()
            }
        }

    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
struct HomeButton: View {
    let title: String
    let icon: String
    let color: Color
    let destination: AnyView

    var body: some View {
        NavigationLink(destination: destination) {
            HStack {
                Image(systemName: icon)
                    .font(.system(size: 30))
                    .foregroundColor(.white)
                    .frame(width: 50, height: 50)

                Text(title)
                    .font(.headline)
                    .foregroundColor(.white)

                Spacer()
            }
            .padding()
            .background(color)
            .cornerRadius(15)
            .shadow(radius: 5)
        }
    }
}

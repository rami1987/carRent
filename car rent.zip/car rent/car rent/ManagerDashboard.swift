//
//  ManagerDashboard.swift
//  car rent
//
//  Created by Macbook  on 01/10/2025.
//

import SwiftUI
/// main view for  admin have tab bar 4 tabs
struct ManagerDashboard: View {
    @State private var selectedTab = 0
     @State private var cars: [Carrr] = []
     @State private var rentals: [CarRental] = []
     
     var body: some View {
         TabView(selection: $selectedTab) {
             // Tab 1: Create New Car
             NavigationView {
                 AdminController()
             }
             .tabItem {
                 Image(systemName: "plus.circle.fill")
                 Text("Add Car")
             }
             .tag(3)
             
             // Tab 2: Available Cars
             NavigationView {
                 AvailableCarsView()
             }
             .tabItem {
                 Image(systemName: "car.fill")
                 Text("Available Cars")
             }
             .tag(1)
             
             // Tab 3: Rented Cars
             NavigationView {
               //  RentedCarsView()
             }
             .tabItem {
                 Image(systemName: "car.2.fill")
                 Text("Rented Cars")
             }
             .tag(2)
             
             // Tab 4: All Cars (Update/Delete)
             NavigationView {
                 carListView()
             }
             .tabItem {
                 Image(systemName: "list.bullet")
                 Text("All Cars")
             }
             .tag(0)
         }
         .accentColor(.blue)
         .onAppear {
             loadData()
         }
     }
     
     private func loadData() {
         cars = AdminCoreDataManager.fetchAllCars()
         rentals = RentalDataManager.fetchAllRentals()
     }
}

struct ManagerDashboard_Previews: PreviewProvider {
    static var previews: some View {
        ManagerDashboard()
    }
}

//
//  CoreDataManager.swift
//  car rent
//
//  Created by Macbook  on 31/08/2025.
//
import SwiftUI
import CoreData
import CryptoKit
import Foundation

public class CurrentCustomer:ObservableObject{
    @Published var currentUser: Customerr?
    @Published var isLoggedIn: Bool = false

}

public class CoreDataManager {
    
    static let shared = CoreDataManager()
    static let preview = CoreDataManager(inMemory: true)
    let persistentContainer: NSPersistentContainer

    private init(inMemory:Bool = false) {
        persistentContainer = NSPersistentContainer(name: "CarRent")
        if inMemory {
            persistentContainer.persistentStoreDescriptions.first?.url = URL(fileURLWithPath: "/dev/null")
                }
        persistentContainer.loadPersistentStores { description, error in
            if let error = error {
                fatalError("Core Data store failed to load: \(error.localizedDescription)")
            }
        }
    }
    
    //related to Customer entity register
    func saveCustomer(name: String, userName: String, mail: String, password: String,pin:String,ismanager:Bool,              userManager:CurrentCustomer
)->Bool {
            let context = persistentContainer.viewContext
            
            let newCustomer = Customerr(context: context)
            newCustomer.id = UUID() // Auto-generate UUID
            newCustomer.name = name
            newCustomer.userName = userName
            newCustomer.email = mail
            newCustomer.password = password
            newCustomer.isManager = ismanager
            
            do {
                try context.save()
                print("Customer saved successfully!")
                userManager.currentUser = newCustomer
                userManager.currentUser?.islogged = true
                userManager.isLoggedIn = true
                print(newCustomer)
                return true
            } catch {
                print("Failed to save customer: \(error.localizedDescription)")
                return false
            }
        }
    //realated to Customer entity fetch some record from Customer entity
    func loginUser(email: String, password: String,userManager:CurrentCustomer) -> (success: Bool, customer: Customerr?, error: String?) {
            let context = persistentContainer.viewContext
         print("supose to be \(password)")
            // Basic validation
            guard !email.isEmpty else {
                print("email can not be empty")
                return (false, nil, "Email cannot be empty")
            }
            
            guard !password.isEmpty else {
                return (false, nil, "Password cannot be empty")
            }
        guard isValidEmail(email) else{
            print("email or password is wrong")
            return (false, nil, "email or password is wrong")

        }
           
            
            // Fetch customer with matching email and password
            let fetchRequest: NSFetchRequest<Customerr> = Customerr.fetchRequest()//this func return object coredata that relate to customer entity
            fetchRequest.predicate = NSPredicate(format: "email == %@ AND password == %@", email, password)
            fetchRequest.fetchLimit = 1
            
            do {
                let results = try context.fetch(fetchRequest)
             
                if let customer = results.first {
                             // Successful login
                    userManager.currentUser = customer
                    userManager.currentUser?.islogged = true
                             print("Login successful for: \(customer.name ?? "Unknown")")
                            
                             return (true, customer, nil)
                         } else {
                             // No matching user found
                             print("why im typing correctly")
                             return (false, nil, "Invalid email or password")
                         }
                     } catch {
                         print("Login fetch error: \(error.localizedDescription)")
                         return (false, nil, "Login failed. Please try again.")
                     }
                 }
    private func isValidEmail(_ email: String) -> Bool {
            let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
            return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: email)
        }
    
    // MARK: - Load Current User on App Start
        private func loadCurrentUser() {
            
            let context = persistentContainer.viewContext
            let request: NSFetchRequest<Customerr> = Customerr.fetchRequest()
            
            //the predicate check which custormer islogged 
            request.predicate = NSPredicate(format: "islogged == true")
            request.fetchLimit = 1
            
            do {
                let users = try context.fetch(request)
                if let user = users.first {
                   // userManager.currentUser = user
                  //  userManager.currentUser?.islogged = true
                    print("Loaded current user: \(user.name ?? "Unknown")")
                } else {
                //    userManager.currentUser = nil
                    print("No logged in user found")
                }
            } catch {
                print("Error loading current user: \(error)")
             //   userManager.currentUser = nil
            }
        }
}

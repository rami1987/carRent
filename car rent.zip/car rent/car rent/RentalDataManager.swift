//
//  RentalDataManager.swift
//  car rent
//
//  Created by Macbook  on 01/10/2025.
//

import Foundation
import CoreData
import UIKit

class RentalDataManager {
    static let context = CoreDataManager.shared.persistentContainer.viewContext
    
    // MARK: - Create Rental Methods
    
    
    /// إنشاء تأجير جدي
    /// i prefer the next method to save CarRental record to send the two uuid for car and customer fetch them them save the car rental record
    static func createRental(
        car: Carrr,
        user: CurrentCustomer,
        startDate: Date,
        returnDate: Date,
        days: Int16
    ) -> Bool {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        let stringStartDate = dateFormatter.string(from: startDate)
        let stringReturnDate = dateFormatter.string(from: returnDate)

        let newRental = CarRental(context: context)
        
        newRental.id = UUID()
        newRental.startDay = stringStartDate
        newRental.returnDate = stringReturnDate
        newRental.days = days
        newRental.returned = false
        if let rent = user.currentUser{
            newRental.renter = rent
        }else{
            print("can't found user")
            return false 
        }
        // إعداد العلاقات
        newRental.car = car
        if let cust =  user.currentUser {
            newRental.renter = cust

        }else { print("car error")
            return false
        }
        
        // تحديث حالة السيارة
        car.isavailable = false
        
        do {
            try context.save()
            print("✅ Rental created successfully!")
            return true
        } catch {
            print("❌ Failed to create rental: \(error.localizedDescription)")
            return false
        }
    }
    
    /// إنشاء تأجير باستخدام IDs
    static func createRental(
        carId: UUID,
        customerId: UUID,
        startDate: Date,
        returnDate: Date,
        days: Int16
    ) -> Bool {
        //this is the safe way to save car and customer get the uuid in params and fetch them later then we save in core data
        guard let car = fetchCar(by: carId),
              let customer = fetchCustomer(by: customerId) else {
            print("❌ Car or Customer not found")
            return false
        }
        
        return createRental(
            car: car,
            user: CurrentCustomer(),//NOTE THAT U CREATED NEW NOW CURRENT IS NOT UNIUQE
            startDate: startDate,
            returnDate: returnDate,
            days: days
        )
    }
    
    // MARK: - Fetch Rental Methods
    
    /// جلب جميع التأجيرات
    /// note here we don't use pridicate we don't want to filter any record .
    static func fetchAllRentals() -> [CarRental] {
        let fetchRequest: NSFetchRequest<CarRental> = CarRental.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "startDay", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        do {
            let rentals = try context.fetch(fetchRequest)
            return rentals
        } catch {
            print("❌ Failed to fetch rentals: \(error.localizedDescription)")
            return []
        }
    }
    
    /// جلب التأجيرات النشطة (لم يتم إرجاعها)
    static func fetchActiveRentals() -> [CarRental] {
        let fetchRequest: NSFetchRequest<CarRental> = CarRental.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "returned == false")
        let sortDescriptor = NSSortDescriptor(key: "startDay", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        do {
            let rentals = try context.fetch(fetchRequest)
            return rentals
        } catch {
            print("❌ Failed to fetch active rentals: \(error.localizedDescription)")
            return []
        }
    }
    
    /// جلب التأجيرات المكتملة (تم إرجاعها)
    static func fetchCompletedRentals() -> [CarRental] {
        let fetchRequest: NSFetchRequest<CarRental> = CarRental.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "returned == true")
        let sortDescriptor = NSSortDescriptor(key: "returnDate", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        do {
            let rentals = try context.fetch(fetchRequest)
            return rentals
        } catch {
            print("❌ Failed to fetch completed rentals: \(error.localizedDescription)")
            return []
        }
    }
    
    /// جلب تأجيرات سيارة معينة
    /// this func fetch specific car for all the rental which been rented
    static func fetchRentalsForCar(_ car: Carrr) -> [CarRental] {
        let fetchRequest: NSFetchRequest<CarRental> = CarRental.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "car == %@", car)
        let sortDescriptor = NSSortDescriptor(key: "startDay", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        do {
            let rentals = try context.fetch(fetchRequest)
            return rentals
        } catch {
            print("❌ Failed to fetch rentals for car: \(error.localizedDescription)")
            return []
        }
    }
    

    /// جلب تأجيرات عميل معين
    /// this means if the customer has many rentals cars ,get specific rentals that regard to one customer
    static func fetchRentalsForCustomer(_ customer: Customerr) -> [CarRental] {
        let fetchRequest: NSFetchRequest<CarRental> = CarRental.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "renter == %@", customer)
        let sortDescriptor = NSSortDescriptor(key: "startDay", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        do {
            let rentals = try context.fetch(fetchRequest)
            return rentals
        } catch {
            print("❌ Failed to fetch rentals for customer: \(error.localizedDescription)")
            return []
        }
    }
    //this function doing the same functionality for get retals for specific customer
    // note we pass here the uuid for CarRental record not uuid for car or customer
    /// جلب تأجير عميل معين  بواسطة ID هذه الداله تشبه الداله السابقه ولاكن هنا بواسطه الid
    static func fetchRental(by id: UUID) -> CarRental? {
        let fetchRequest: NSFetchRequest<CarRental> = CarRental.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %@", id as CVarArg)
        
        do {
            let rentals = try context.fetch(fetchRequest)
            return rentals.first
        } catch {
            print("❌ Failed to fetch rental: \(error.localizedDescription)")
            return nil
        }
    }
    
    /// جلب التأجيرات التي تنتهي في تاريخ معين
    static func fetchRentalsEndingOn(_ date: String) -> [CarRental] {
        let fetchRequest: NSFetchRequest<CarRental> = CarRental.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "returnDate == %@", date)
        
        do {
            let rentals = try context.fetch(fetchRequest)
            return rentals
        } catch {
            print("❌ Failed to fetch rentals ending on date: \(error.localizedDescription)")
            return []
        }
    }
    
    // MARK: - Update Rental Methods
    
    /// تحديث حالة التأجير إلى "تم الإرجاع"
    static func returnRental(_ rental: CarRental) -> Bool {
        rental.returned = true
        rental.car.isavailable = true // إعادة السيارة إلى الحالة المتاحة
        
        do {
            try context.save()
            print("✅ Rental returned successfully!")
            return true
        } catch {
            print("❌ Failed to return rental: \(error.localizedDescription)")
            return false
        }
    }
    
    /// تحديث تاريخ الإرجاع
    static func updateReturnDate(_ rental: CarRental, newReturnDate: String, additionalDays: Int16) -> Bool {
        rental.returnDate = newReturnDate
        rental.days += additionalDays
        
        do {
            try context.save()
            print("✅ Return date updated successfully!")
            return true
        } catch {
            print("❌ Failed to update return date: \(error.localizedDescription)")
            return false
        }
    }
    
    /// تمديد فترة التأجير
    static func extendRental(_ rental: CarRental, additionalDays: Int16, newReturnDate: String) -> Bool {
        return updateReturnDate(rental, newReturnDate: newReturnDate, additionalDays: additionalDays)
    }
    
    // MARK: - Delete Rental Methods
    
    /// حذف تأجير
    static func deleteRental(_ rental: CarRental) -> Bool {
        // إعادة السيارة إلى الحالة المتاحة قبل الحذف
        rental.car.isavailable = true
        
        context.delete(rental)
        
        do {
            try context.save()
            print("✅ Rental deleted successfully!")
            return true
        } catch {
            print("❌ Failed to delete rental: \(error.localizedDescription)")
            return false
        }
    }
    
    /// حذف تأجير بواسطة ID
    static func deleteRental(by id: UUID) -> Bool {
        guard let rental = fetchRental(by: id) else {
            print("❌ Rental not found")
            return false
        }
        
        return deleteRental(rental)
    }
    
    // MARK: - Utility Methods
    
    /// حساب الإيرادات من التأجيرات
    static func calculateTotalRevenue() -> Double {
        let rentals = fetchCompletedRentals()
        var totalRevenue: Double = 0
        
        for rental in rentals {
            let car = rental.car
                let rentalRevenue = Double(car.pricePerDay) * Double(rental.days)
                totalRevenue += rentalRevenue
            
        }
        
        return totalRevenue
    }
    
    /// حساب الإيرادات لفترة محددة
    static func calculateRevenueForPeriod(startDate: String, endDate: String) -> Double {
        let rentals = fetchCompletedRentals()
        var periodRevenue: Double = 0
        
        for rental in rentals {
            if (rental.returnDate >= startDate && rental.returnDate <= endDate){
                let car = rental.car
                    let rentalRevenue = Double(car.pricePerDay) * Double(rental.days)
                    periodRevenue += rentalRevenue
                
            }
        }
        
        return periodRevenue
    }
    
    /// التحقق من توفر السيارة في فترة معينة
    static func isCarAvailable(_ car: Carrr, from startDate: String, to endDate: String) -> Bool {
        /////we fetch all the rentals for one car
        let carRentals = fetchRentalsForCar(car)
        ///here we checkj only with cars that not yet retutrn else return true 
        for rental in carRentals where rental.returned == false {
            let rentalStart = rental.startDay
               let rentalEnd = rental.returnDate
                // التحقق من التعارض في التواريخ
                if (startDate <= rentalEnd && endDate >= rentalStart) {
                    return false
                }
            
        }
        
        return true
    }
 /*
    /// جلب التأجيرات القادمة (في الأيام السبعة القادمة)
    static func fetchUpcomingRentals(days: Int = 7) -> [CarRental] {
        let activeRentals = fetchActiveRentals()
        let currentDate = Date()
        let calendar = Calendar.current
        let futureDate = calendar.date(byAdding: .day, value: days, to: currentDate)!
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        let currentDateString = dateFormatter.string(from: currentDate)
        let futureDateString = dateFormatter.string(from: futureDate)
        
        return activeRentals.filter { rental in
            guard let startDate = rental.startDay else { return false }
            return startDate >= currentDateString && startDate <= futureDateString
        }
    }*/
    
    /// جلب التأجيرات المنتهية التي لم تُرجع بعد
    static func fetchOverdueRentals() -> [CarRental] {
        let activeRentals = fetchActiveRentals()
        let currentDate = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let currentDateString = dateFormatter.string(from: currentDate)
        
        return activeRentals.filter { rental in
             let returnDate = rental.returnDate
            return returnDate < currentDateString && rental.returned == false
        }
    }
    
    // MARK: - Helper Methods
    
    private static func fetchCar(by id: UUID) -> Carrr? {
        let fetchRequest: NSFetchRequest<Carrr> = Carrr.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %@", id as CVarArg)
        
        do {
            let cars = try context.fetch(fetchRequest)
            return cars.first
        } catch {
            print("❌ Failed to fetch car: \(error.localizedDescription)")
            return nil
        }
    }
    
    private static func fetchCustomer(by id: UUID) -> Customerr? {
        let fetchRequest: NSFetchRequest<Customerr> = Customerr.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %@", id as CVarArg)
        
        do {
            let customers = try context.fetch(fetchRequest)
            return customers.first
        } catch {
            print("❌ Failed to fetch customer: \(error.localizedDescription)")
            return nil
        }
    }
}

//
//  Carr.swift
//  car rent
//
//  Created by Macbook  on 06/09/2025.
//

import Foundation
import SwiftUI
// Carr for car data

struct Carr:Identifiable{
    
    var id=UUID()
    var title:String
    var headline:String
    var image:String
    var gradientColors:[Color] 
    var description:String
    var models:[String]
    var isavailable:Bool
    var lastmaintainceDate:String = ""
    var pricePerDay:Int
}


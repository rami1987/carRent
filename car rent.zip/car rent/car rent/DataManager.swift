//
//  DataManager.swift
//  car rent
//
//  Created by Macbook  on 01/09/2025.
//

import Foundation
import SwiftUI
import CoreData
import CryptoKit
func hashPassword(_ password: String) -> String {
    let data = Data(password.utf8)
    let hash = SHA256.hash(data: data)
    return hash.compactMap { String(format: "%02x", $0) }.joined()
}

class DataManager: ObservableObject {
 /*
    private let context = CoreDataManager.shared.persistentContainer.viewContext
    
    @Published var currentUser: Customer?
    @Published var cars: [Car] = []
    @Published var isLoggedIn = false
    @Published var userRentals: [Rental] = []
    
    // User Management
    func registerUser(username: String, password: String, email: String) -> Bool {
        let fetchRequest: NSFetchRequest<Car> = Car.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "username == %@ OR email == %@", username, email)
        
        do {
            let existingUsers = try context.fetch(fetchRequest)
            guard existingUsers.isEmpty else {
                print("Username or email already exists")
                return false
            }
            
            let newUser = Customer(context: context)
            newUser.id = UUID()
            newUser.userName = username
            newUser.password = hashPassword(password)
            newUser.email = email
            
            try context.save()
            return true
        } catch {
                  print("Registration failed: \(error)")
                  return false
              }
          }
          
          
    func logout() {
        currentUser = nil
        isLoggedIn = false
        userRentals = []
    }
    
    // Car Management
    func loadCars() {
        let fetchRequest: NSFetchRequest<Car> = Car.fetchRequest()
        
        do {
            cars = try context.fetch(fetchRequest)
            
            // If no cars exist, create sample data
            if cars.isEmpty {
                createSampleCars()
                cars = try context.fetch(fetchRequest)
            }
        } catch {
            print("Failed to fetch cars: \(error)")
        }
    }
    */
   /* private func createSampleCars() {
        let carMakes = ["Toyota", "Honda", "Ford", "BMW", "Mercedes", "Audi"]
        let carModels = ["Camry", "Civic", "F-150", "X5", "C-Class", "A4"]
        
        for i in 0..<carMakes.count {
            let newCar = Car(context: context)
            newCar.id = UUID()
            newCar.make = carMakes[i]
            newCar.model = carModels[i]
            newCar.year = Int16(2020 + i % 3)
            newCar.dailyRate = Double(30 + i * 10)
            newCar.isavailable = true
        }
        
        do {
            try context.save()
        } catch {
            print("Failed to create sample cars: \(error)")
        }
    }
    
    // Rental Management
    func rentCar(_ car: Car, startDate: Date, endDate: Date) -> Bool {
        guard let user = currentUser, car.isAvailable else { return false }
        
        // Calculate rental details
        let calendar = Calendar.current
        let components = calendar.dateComponents([.day], from: startDate, to: endDate)
        guard let days = components.day, days > 0 else { return false }
        
        let totalCost = Double(days) * car.dailyRate
        
        // Create rental record
        let newRental = Rental(context: context)
        newRental.id = UUID()
        newRental.startDate = startDate
        newRental.endDate = endDate
        newRental.totalDays = Int16(days)
        newRental.totalCost = totalCost
        newRental.user = user
        newRental.car = car
        
        // Update car availability
        car.isAvailable = false
        
        do {
            try context.save()
            loadCars() // Refresh the car list
            loadUserRentals() // Refresh user rentals
            return true
        } catch {
            print("Failed to rent car: \(error)")
            context.rollback()
            return false
        }
    }
    
    func returnCar(_ rental: Rental) -> Bool {
        guard let car = rental.car else { return false }
        
        // Update car availability
        car.isAvailable = true
        
        // Remove the rental (or you could keep it for history)
        context.delete(rental)
        
        do {
            try context.save()
            loadCars() // Refresh the car list
            loadUserRentals() // Refresh user rentals
            return true
        } catch {
            print("Failed to return car: \(error)")
            context.rollback()
            return false
        }
    }
    
    func loadUserRentals() {
        guard let user = currentUser else {
            userRentals = []
            return
        }
        
        let fetchRequest: NSFetchRequest<Rental> = Rental.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "user == %@", user)
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "startDate", ascending: false)]
        
        do {
            userRentals = try context.fetch(fetchRequest)
        } catch {
            print("Failed to fetch user rentals: \(error)")
            userRentals = []
        }
    }
    
    func getActiveRentals() -> [Rental] {
        return userRentals.filter { $0.car?.isAvailable == false }
    }
    
    func getRentalHistory() -> [Rental] {
        return userRentals.filter { $0.car?.isAvailable == true }
    }
    */
}


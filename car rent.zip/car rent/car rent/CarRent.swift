//
//  CarRent.swift
//  car rent
//
//  Created by Macbook  on 29/08/2025.
//

import Foundation
import SwiftUI
import CoreData

@objc(Rental)
public class CarRental : NSManagedObject, Identifiable{
    @NSManaged public var id: UUID
    @NSManaged public var days:Int16;
    @NSManaged public var startDay:String
    @NSManaged public var returnDate:String;
    @NSManaged public var returned:Bool;
    //relationship variables
    @NSManaged  var car:Carrr
    @NSManaged  var renter:Customerr// New field to store the renter
    
    static func fetchRequest() -> NSFetchRequest<CarRental> {
        return NSFetchRequest<CarRental>(entityName: "Rental")
    }
    
}
    extension CarRental {
        static func fetchRequest() -> NSFetchRequest<Carrr> {
            NSFetchRequest<Carrr>(entityName: "CarRental")
        }
    }



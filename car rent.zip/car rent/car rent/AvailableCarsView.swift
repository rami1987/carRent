//
//  AvailableCarsView.swift
//  car rent
//
//  Created by Macbook  on 01/10/2025.
//

import SwiftUI

struct AvailableCarsView: View {
    @State private var availableCars: [Carrr] = []
      
      var body: some View {
          List {
              if availableCars.isEmpty {
                  Text("No available cars")
                      .foregroundColor(.secondary)
                      .italic()
              } else {
                  ForEach(availableCars, id: \.id) { car in
                      
                  }
              }
          }
          .navigationTitle("Available Cars")
          .onAppear {
              loadAvailableCars()
          }
      }
      
      private func loadAvailableCars() {
          let allCars = AdminCoreDataManager.fetchAllCars()
          availableCars = allCars.filter { $0.isavailable }
      }
    
}

/*struct AvailableCarsView_Previews: PreviewProvider {
    AvailableCarsView
}
*/

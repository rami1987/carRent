//
//  Customer.swift
//  car rent
//
//  Created by Macbook  on 28/08/2025.
//

import Foundation
import SwiftUI
import CoreData

@objc(Customer)
class Customerr: NSManagedObject ,Identifiable, Encodable{
    @NSManaged  var id: UUID
    @NSManaged  var name:String
    @NSManaged  var userName:String
    @NSManaged  var password:String
    @NSManaged  var email:String
    @NSManaged var isManager:Bool
    @NSManaged var islogged:Bool
    @NSManaged  var rentals: Set<CarRental>?//this we add to core data in the relationship area not in attributs
    
    
}
extension Customerr {
    static func fetchRequest() -> NSFetchRequest<Customerr> {
        NSFetchRequest<Customerr>(entityName: "Customer")
    }
    
}

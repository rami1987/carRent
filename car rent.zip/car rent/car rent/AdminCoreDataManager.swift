//
//  AdminCoreDataManager.swift
//  car rent
//
//  Created by Macbook  on 24/09/2025.
//

import Foundation
import UIKit
import CoreData
////this can handle the all method for Car entity
class AdminCoreDataManager{
    
    static let context =  CoreDataManager.shared.persistentContainer.viewContext
    
    
    static func createCar(
        title: String,
        headline: String,
        image: UIImage,
        gradientColors: [UIColor],
        carDescription: String,
        models: [String],
        isAvailable: Bool = true,
        lastMaintenance: String = "",
        pricePerDay: Int16
    ) -> Bool {
        
        let newCar = Carrr(context: context)
        
        // 1. الخصائص العادية - خارج do-catch
        newCar.id = UUID()
        newCar.pricePerDay = pricePerDay
        newCar.title = title
        newCar.headline = headline
        newCar.carDescription = carDescription
        newCar.isavailable = isAvailable
        newCar.lastmaintainceDate = lastMaintenance
        newCar.gradientColors = gradientColors
        newCar.image = image
        newCar.models = models
                
// 2. التحويل اليدوي للـ 
        
        // 3. حفظ البيانات في Core Data
        do {
            try context.save()
            print("✅ Car added successfully!")
            return true
        } catch {
            print("❌ Failed to save car: \(error.localizedDescription)")
            return false
        }
    }
    
    
    // جلب جميع السيارات
    static func fetchAllCars() -> [Carrr] {
        let fetchRequest: NSFetchRequest<Carrr> = Carrr.fetchRequest()
        
        // يمكنك إضافة sorting لو تريد
        let sortDescriptor = NSSortDescriptor(key: "title", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        do {
            let cars = try context.fetch(fetchRequest)
            return cars
        } catch {
            print("❌ Failed to fetch cars: \(error.localizedDescription)")
            return []
        }
    }
    
    // جلب سيارة by ID
    static func fetchCar(by id: UUID) -> Carrr? {
        let fetchRequest: NSFetchRequest<Carrr> = Carrr.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %@", id as CVarArg)
        
        do {
            let cars = try context.fetch(fetchRequest)
            return cars.first
        } catch {
            print("❌ Failed to fetch car: \(error.localizedDescription)")
            return nil
        }
    }
    
    // حذف سيارة
    static func deleteCar(_ car: Carrr) -> Bool {
        context.delete(car)
        
        do {
            try context.save()
            return true
        } catch {
            print("❌ Failed to delete car: \(error.localizedDescription)")
            return false
        }
    }
    static func getAvailableCars() -> [Carrr] {
           let request: NSFetchRequest<Carrr> = Carrr.fetchRequest()
           
           // فلترة السيارات المتاحة فقط
           request.predicate = NSPredicate(format: "isavailable == %@", NSNumber(value: true))
           
           // ترتيب النتائج (اختياري)
           request.sortDescriptors = [NSSortDescriptor(key: "title", ascending: true)]
           
           do {
               let availableCars = try context.fetch(request)
               print("✅ Found \(availableCars.count) available cars")
               return availableCars
           } catch {
               print("❌ Failed to fetch available cars: \(error.localizedDescription)")
               return []
           }
       }
}

//
//  AdminController.swift
//  car rent
//
//  Created by Macbook  on 24/09/2025.
//

import SwiftUI

struct AdminController: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.presentationMode) var presentationMode
    
    @State private var title = ""
    @State private var headline = ""
    @State private var imageName = ""
    @State private var carDescription = ""
    @State private var modelsText:String = ""
    @State private var lastMaintenanceDate = ""
    @State private var isAvailable = false
    @State private var alertMessage = ""
    @State private var showingAlert = false
    let carColors:[UIColor]? = [
            UIColor(named: "ColorMercedesLight") ?? UIColor.blue,    // fallback إذا لم يوجد
            UIColor(named: "ColorMercedesDark") ?? UIColor.systemBlue
        ]

     var image: UIImage? {
            return UIImage(named: imageName)
        }
     var model:[String]?{
        return modelsText.components(separatedBy: ",")
    }
        
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Car Information")) {
                    TextField("Car Title", text: $title)
                    TextEditor(text: $headline)
                        .frame(height: 70)
                    TextField("Image Name", text: $imageName)
                    TextField("Last Maintenance Date", text: $lastMaintenanceDate)
                    
                    Toggle("Is Available", isOn: $isAvailable)
                }
                
                Section(header: Text("Description")) {
                    TextEditor(text: $carDescription)
                        .frame(height: 100)
                }
                
                Section(header: Text("Models (comma separated)")) {
                    TextField("e.g., Model X, Model Y, Model Z", text: $modelsText)
                }
                
                Section {
                    Button("Add Car") {
                        addCar()
                    }
                    .disabled(!isFormValid)
                    .frame(maxWidth: .infinity)
                    .foregroundColor(.white)
                    .padding()
                    .background(isFormValid ? Color.blue : Color.gray)
                    .cornerRadius(10)
                }
            }
            .navigationTitle("Add New Car")
            .navigationBarItems(
                leading: Button("Cancel") {
                    presentationMode.wrappedValue.dismiss()
                },
                trailing: Button("Clear") {
                    clearForm()
                }
            )
            .alert(isPresented: $showingAlert) {
                Alert(
                    title: Text("Message"),
                    message: Text(alertMessage),
                    dismissButton: .default(Text("OK"))
                )
            }
        }
    }
    
    private var isFormValid: Bool {
        !title.isEmpty &&
        !headline.isEmpty &&
        !imageName.isEmpty &&
        !carDescription.isEmpty &&
        !modelsText.isEmpty
    }
    
    private func addCar() {
       
        guard isFormValid else {
            alertMessage = "Please fill in all required fields"
            showingAlert = true
            return
        }
        
        do {
            //calling the function in Admin Core Data
            let isadded = AdminCoreDataManager.createCar(title: title, headline: headline, image: (image ?? UIImage(named: "bmw"))!,gradientColors: carColors ?? [UIColor.gray,UIColor.white], carDescription: carDescription, models: model ?? ["asd","as"], pricePerDay: 1500)
            if isadded == true{
                print ("saved ")
            }else {print("fail save")}
            
            
            
        }
        
        clearForm()
        
    }
    func clearForm() {
        title = ""
        headline = ""
        imageName = ""
        carDescription = ""
        modelsText = ""
        lastMaintenanceDate = ""
        isAvailable = true
    }
}
struct AdminController_Previews: PreviewProvider {
    static var previews: some View {
        AdminController()
    }
}

//
//  User.swift
//  car rent
//
//  Created by Macbook  on 27/08/2025.
//

import Foundation
class User: NSManagedObject, Identifiable{
    @NSManaged  private var name:String
    @NSManaged private var userName:String
    @NSManaged private var password:String
    
    init(name: String, password: String,userName: String) {
        self.name = name
        self.password = password
        self.userName = userName
    }
    
    func getUser()->User{
        return self
    }
    }

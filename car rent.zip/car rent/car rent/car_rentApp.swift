//
//  car_rentApp.swift
//  car rent
//
//  Created by Macbook  on 21/08/2025.
//

import SwiftUI

@main
struct car_rentApp: App {
    @StateObject private var userManager = CurrentCustomer()
    
    init(){
 Setformer.registerValueTransformers()

    }
    var body: some Scene {
            
        WindowGroup {
         
           Login(email: "", password: "")
                .environmentObject(userManager)
        }
    }
}

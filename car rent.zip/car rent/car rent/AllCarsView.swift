//
//  AllCarsView.swift
//  car rent
//
//  Created by Macbook  on 01/10/2025.
//

import SwiftUI

struct AllCarsView: View {
    @State private var cars: [Carrr] = []
      @State private var showingDeleteAlert = false
      @State private var carToDelete: Carrr?
      
      var body: some View {
          List {
              ForEach(cars, id: \.id) { car in
                  NavigationLink(destination: EditCarView(car: car)) {
                      HStack {
                          CarRowView(car: car)
                          
                          Spacer()
                          
                          // Delete Button
                          Button(action: {
                              carToDelete = car
                              showingDeleteAlert = true
                          }) {
                              Image(systemName: "trash")
                                  .foregroundColor(.red)
                          }
                          .buttonStyle(BorderlessButtonStyle())
                      }
                  }
              }
          }
          .navigationTitle("All Cars")
          .toolbar {
              ToolbarItem(placement: .navigationBarTrailing) {
                  EditButton()
              }
          }
          .alert("Delete Car", isPresented: $showingDeleteAlert) {
              Button("Cancel", role: .cancel) { }
              Button("Delete", role: .destructive) {
                  if let car = carToDelete {
                      deleteCar(car)
                  }
              }
          } message: {
              Text("Are you sure you want to delete this car?")
          }
          .onAppear {
              loadCars()
          }
      }
      
      private func loadCars() {
          cars = CarDataManager.fetchAllCars()
      }
      
      private func deleteCar(_ car: Carrr) {
          if CarDataManager.deleteCar(car) {
              loadCars() // Refresh the list
          }
      }
}
/*
struct AllCarsView_Previews: PreviewProvider {
    static var previews: some View {
        AllCarsView()
    }
}*/

//
//  CustomerManager.swift
//  car rent
//
//  Created by Macbook  on 26/09/2025.
//this class to handle the login off the user once log in the app 

import Foundation
class UserManager: ObservableObject {
    @Published var user: Ccustomer? {
        didSet {
            saveUser()
        }
    }
    
    private let key = "user_data"
    
    init() {
        loadUser()
    }
    
    private func saveUser() {
        if let user = user {
            let encoder = JSONEncoder()
            if let data = try? encoder.encode(user) {
                UserDefaults.standard.set(data, forKey: key)
            }
        } else {
            UserDefaults.standard.removeObject(forKey: key)
        }
    }
    
    private func loadUser() {
        if let data = UserDefaults.standard.data(forKey: key) {
            let decoder = JSONDecoder()
            if let savedUser = try? decoder.decode(Ccustomer.self, from: data) {
                self.user = savedUser
            }
        }
    }
}


import Foundation
import UIKit

// MARK: - UIColor Array Transformer
@objc(UIColorArrayTransformer)
final class UIColorArrayTransformer: NSSecureUnarchiveFromDataTransformer {
    static let name = NSValueTransformerName(rawValue: "UIColorArrayTransformer")
    
    override static var allowedTopLevelClasses: [AnyClass] {
        return [NSArray.self, UIColor.self]
    }
    
    public static func register() {
        let transformer = UIColorArrayTransformer()
        ValueTransformer.setValueTransformer(transformer, forName: name)
    }
}

// MARK: - UIImage Transformer
@objc(UIImageTransformer)
final class UIImageTransformer: ValueTransformer {
    static let name = NSValueTransformerName(rawValue: "UIImageTransformer")
    
    override class func transformedValueClass() -> AnyClass {
        return NSData.self
    }
    
    override class func allowsReverseTransformation() -> Bool {
        return true
    }
    
    override func transformedValue(_ value: Any?) -> Any? {
        guard let image = value as? UIImage else { return nil }
        return image.pngData()
    }
    
    override func reverseTransformedValue(_ value: Any?) -> Any? {
        guard let data = value as? Data else { return nil }
        return UIImage(data: data)
    }
    
    public static func register() {
        let transformer = UIImageTransformer()
        ValueTransformer.setValueTransformer(transformer, forName: name)
    }
}

// MARK: - String Array Transformer
@objc(StringArrayTransformer)
final class StringArrayTransformer: ValueTransformer {
    static let name = NSValueTransformerName(rawValue: "StringArrayTransformer")
    
    override class func transformedValueClass() -> AnyClass {
        return NSData.self
    }
    
    override class func allowsReverseTransformation() -> Bool {
        return true
    }
    
    override func transformedValue(_ value: Any?) -> Any? {
        guard let strings = value as? [String] else { return nil }
        
        do {
            return try JSONSerialization.data(withJSONObject: strings, options: [])
        } catch {
            print("Error transforming strings: \(error)")
            return nil
        }
    }
    
    override func reverseTransformedValue(_ value: Any?) -> Any? {
        guard let data = value as? Data else { return nil }
        
        do {
            return try JSONSerialization.jsonObject(with: data, options: []) as? [String]
        } catch {
            print("Error reverse transforming strings: \(error)")
            return nil
        }
    }
    
    public static func register() {
        let transformer = StringArrayTransformer()
        ValueTransformer.setValueTransformer(transformer, forName: name)
    }
}

class Setformer{
    static func registerValueTransformers() {
            UIColorArrayTransformer.register()
            UIImageTransformer.register()
            StringArrayTransformer.register()
            
            print("✅ Value Transformers registered successfully")
        }
}


  

//
//  Car.swift
//  car rent
//
//  Created by Macbook  on 22/08/2025.
//

import Foundation
import SwiftUI
import CoreData

@objc(Car)
class Carrr:NSManagedObject, Identifiable{

}
    
extension Carrr{
    @NSManaged var pricePerDay:Int16
    @NSManaged  var gradientColors: [UIColor]?
    @NSManaged var id :UUID
    @NSManaged var title:String
    @NSManaged var headline:String
    @NSManaged var image: UIImage?
    @NSManaged  var carDescription:String
    @NSManaged var models: [String]?
    @NSManaged var isavailable:Bool
    @NSManaged var lastmaintainceDate:String
    //we don't need to add carRent list of users ''not nessessay to know how many user rent specific car
    @NSManaged public var rentals: Set<CarRental>?
    
}


extension Carrr {
    static func fetchRequest() -> NSFetchRequest<Carrr> {
        NSFetchRequest<Carrr>(entityName: "Car")
    }
    
    
    // الدالة الأساسية لإنشاء سيارة جديدة
    
}
